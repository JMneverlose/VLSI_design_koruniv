TOP_foled_FIR1 - memory가 apply된 Verification용 unit

pick value unit - slower domain

multi unit - faster domain


v1 = non-blocked
 
v2 = semi-blocked

v3 = improved - blocked